<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('user.css.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

<!-- Back to top button -->
<div class="back-to-top"></div>

<?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<table class="table table-hover">
    <thead>
    <tr align="center">
        <th scope="col">Doctor Name</th>
        <th scope="col">Date</th>
        <th scope="col">Message</th>
        <th scope="col">Status</th>
        <th scope="col">Cancel Appointment</th>
    </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $appoint; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appoints): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr align="center">
        <th ><?php echo e($appoints->doctor_name); ?></th>
        <td><?php echo e($appoints->date); ?></td>
        <td><?php echo e($appoints->message); ?></td>
        <td><?php if($appoints->status=='Approved'): ?>
                <span class="bg-success"><?php echo e($appoints->status); ?></span>
            <?php elseif($appoints->status=='Canceled'): ?>
                <span class="bg-danger"><?php echo e($appoints->status); ?></span>
            <?php else: ?>
                <span class="bg-warning"><?php echo e($appoints->status); ?></span>
            <?php endif; ?>

        </td>
        <td align="center"><a class="btn btn-danger" onclick="return confirm('Are you sure to delete this?')" href="<?php echo e(url('cancel_appoint', $appoints->id)); ?>">Cancel</a> </td>
    </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>

<script src="../assets/js/jquery-3.5.1.min.js"></script>

<script src="../assets/js/bootstrap.bundle.min.js"></script>

<script src="../assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

<script src="../assets/vendor/wow/wow.min.js"></script>

<script src="../assets/js/theme.js"></script>

</body>
</html><?php /**PATH J:\Laravel_Project\Hospital_Project\resources\views/user/appointment/my_appointment.blade.php ENDPATH**/ ?>