<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/public">
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="container-scroller">
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="container-fluid pt-5">


            <form action="<?php echo e(url('edit_doctor',$data->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mt-6">
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success mt-3">
                            <?php echo e(session()->get('message')); ?>

                        </div>

                    <?php endif; ?>

                    <div class="form-group mt-2">
                        <label >Doctor Name</label>
                        <input  style="color: black" type="text" class="form-control" name="name" value="<?php echo e($data->name); ?>">
                    </div>

                    <div class="form-group">
                        <label >Phone</label>
                        <input style="color: black" type="text" class="form-control" name="phone" value="<?php echo e($data->phone); ?>">
                    </div>

                    <div class="form-group">
                        <label >Speciality</label>
                        <select style="color: black" class="form-control" name="speciality">
                            <option><?php echo e($data->speciality); ?></option>
                            <option value="skin">Skin</option>
                            <option value="heart">Heart</option>
                            <option value="eye">Eye</option>
                            <option value="nose">Nose</option>

                        </select>
                    </div>

                    <div class="form-group">
                        <label >Room No</label>
                        <input  style="color: black" type="text" class="form-control" name="room" value="<?php echo e($data->room); ?>">
                    </div>
                        
                        <div class="form-group">
                            <label >Old Image</label>
                            <img width="200" height="200" src="doctorimage/<?php echo e($data->image); ?>" alt="">
                        </div>


                    <div class="form-group">
                        <label >Doctor Image</label>
                        <input type="file" class="form-control-file" name="image">
                    </div>

                    <div class="form-group">
                        <label></label>
                        <input type="submit" class="form-control btn btn-success">
                    </div>
                </div>
            </form>
        </div>




    </div>
</div>
<?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH J:\Laravel_Project\Hospital_Project\resources\views/admin/updatedoctor.blade.php ENDPATH**/ ?>