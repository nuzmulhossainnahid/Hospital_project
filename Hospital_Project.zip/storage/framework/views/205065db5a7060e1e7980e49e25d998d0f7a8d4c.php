<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="container-scroller">
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




        <div >
            <br><br><br>
            
            
            
            
            
            
            
            
            <table class=" max-w-6xl table  table-bordered table-hover bg-light" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Website</th>
                    <th>Message</th>
                    <th>Replay</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($comment->name); ?></td>
                        <td><?php echo e($comment->email); ?></td>
                        <td><?php echo e($comment->website); ?></td>
                        <td><?php echo e($comment->message); ?></td>
                        <td><a href="<?php echo e(url('emailviewcomment', $comment->id)); ?>" class="btn btn-success">Replay</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>






    </div>
</div>
<?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH J:\Laravel_Project\Hospital_Project\resources\views/admin/blogcomment.blade.php ENDPATH**/ ?>