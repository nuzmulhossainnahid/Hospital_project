<?php echo e($slot); ?>

<?php /**PATH J:\Laravel_Project\Hospital_Project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>