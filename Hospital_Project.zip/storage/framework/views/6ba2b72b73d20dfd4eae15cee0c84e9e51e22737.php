<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <base href="/public">
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>
<div class="container-scroller">
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <div class="container-fluid pt-5">


            <form action="<?php echo e(url('sendemailcomment',$data->id)); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <div class="mt-6">
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success mt-3">
                            <?php echo e(session()->get('message')); ?>

                        </div>

                    <?php endif; ?>

                    <div class="form-group mt-2">
                        <label >Greeting</label>
                        <input  style="color: black" type="text" class="form-control" name="greeting">
                    </div>

                    <div class="form-group">
                        <label >Body</label>
                        <input style="color: black" type="text" class="form-control" name="body" >
                    </div>


                    <div class="form-group">
                        <label >Action Text</label>
                        <input  style="color: black" type="text" class="form-control" name="actiontext" >
                    </div>

                    <div class="form-group">
                        <label >Action Url</label>
                        <input  style="color: black" type="text" class="form-control" name="actionurl" >
                    </div>

                    <div class="form-group">
                        <label >End Part</label>
                        <input  style="color: black" type="text" class="form-control" name="endpart">
                    </div>



                    <div class="form-group">
                        <label></label>
                        <input type="submit" class="form-control btn btn-success">
                    </div>
                </div>
            </form>
        </div>
        
    </div>
</div>
<?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH J:\Laravel_Project\Hospital_Project\resources\views/admin/emailviewcomment.blade.php ENDPATH**/ ?>