<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>
<div class="container-scroller">
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <div class="container-fluid pt-5">


            <form action="<?php echo e(url('add_blog')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mt-6">
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success mt-3">
                            <?php echo e(session()->get('message')); ?>

                        </div>

                    <?php endif; ?>

                    <div class="form-group mt-2">
                        <label >Title</label>
                        <input  style="color: black" type="text" class="form-control" name="title">
                    </div>
                        <div class="form-group mt-2">
                            <label >Description</label>
                            <input  style="color: black" type="text" class="form-control" name="description">
                        </div>

                    <div class="form-group">
                        <label >Author Name</label>
                        <input style="color: black" type="text" class="form-control" name="authorname">
                    </div>

                    <div class="form-group">
                        <label >date</label>
                        <input  style="color: black" type="date" class="form-control" name="date">
                    </div>


                    <div class="form-group">
                        <label >Image</label>
                        <input type="file" class="form-control-file" name="image">
                    </div>

                    <div class="form-group">
                        <label></label>
                        <input type="submit" class="form-control btn btn-success">
                    </div>
                </div>
            </form>
        </div>
        
    </div>
</div>
<?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH J:\Laravel_Project\Hospital_Project\resources\views/admin/blog.blade.php ENDPATH**/ ?>