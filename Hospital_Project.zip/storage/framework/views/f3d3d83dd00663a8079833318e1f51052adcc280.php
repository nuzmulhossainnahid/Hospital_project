<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="container-scroller">
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




        <div >
            <br><br><br>
            
            
            
            
            
            
            
            
            <table class=" max-w-6xl table  table-bordered table-hover bg-light" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Authorname</th>
                    <th>date</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($blog->title); ?></td>
                        <td><?php echo e($blog->description); ?></td>
                        <td><?php echo e($blog->authorname); ?></td>
                        <td><?php echo e($blog->date); ?></td>
                        <td><img src="blogimage/<?php echo e($blog->image); ?>" alt="" height="70" width="100"></td>
                        <td><a onclick="return confirm('Are you sure to delete this?')" class="btn btn-danger" href="<?php echo e(url('deleteblog',$blog->id)); ?>">Delete</a>
                            <a class="btn btn-success" href="<?php echo e(url('updateblog',$blog->id)); ?>">Edit</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>






    </div>
</div>
<?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH J:\Laravel_Project\Hospital_Project\resources\views/admin/showblog.blade.php ENDPATH**/ ?>