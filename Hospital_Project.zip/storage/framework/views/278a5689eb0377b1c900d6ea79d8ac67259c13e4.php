<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="container-scroller">
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid ">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="">
            <br>
            <br>
            <br>


            <div class="table-responsive max-w-6xl">
            <table class="table  table-bordered table-hover bg-light">
                <thead>
                <tr>
                    <th >Paticent Name</th>
                    <th >Email</th>
                    <th >phone</th>
                    <th >Doctor Name</th>
                    <th >Message</th>
                    <th >Status</th>
                    <th >Approve</th>
                    <th >Cancel</th>
                    <th >Send Mail</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appoint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr align="center">
                        <th ><?php echo e($appoint->name); ?></th>
                        <td><?php echo e($appoint->email); ?></td>
                        <td><?php echo e($appoint->phone); ?></td>
                        <td><?php echo e($appoint->doctor_name); ?></td>
                        <td><?php echo e($appoint->message); ?></td>
                        <td><?php echo e($appoint->status); ?></td>
                        <td><a class="btn btn-success"  href="<?php echo e(url('approved', $appoint->id)); ?>">A</a> </td>
                        <td><a class="btn btn-danger" onclick="return confirm('Are you sure to delete this?')" href="<?php echo e(url('canceled', $appoint->id)); ?>">C</a> </td>
                        <td><a class="btn btn-success"  href="<?php echo e(url('emailview', $appoint->id)); ?>">Mail</a> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            </div>
        </div>
        </div>

</div>
<?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH J:\Laravel_Project\Hospital_Project\resources\views/admin/showappointment.blade.php ENDPATH**/ ?>